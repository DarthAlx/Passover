<?php

namespace App\Events;

abstract class Event
{
    //
}
